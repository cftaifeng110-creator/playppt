import Foundation
import SwiftUI
import AppKit
import ServiceManagement

@MainActor
final class AppModel: ObservableObject {
    static let shared = AppModel()

    @Published private(set) var devices: [ClickerDevice] = []
    @Published private(set) var selectedDeviceIDs: Set<String> = []
    @Published private(set) var isMonitoring = false
    @Published private(set) var wpsRunning = false
    @Published private(set) var externalDisplayConnected = false
    @Published private(set) var permissionStatus = PermissionService.status()
    @Published private(set) var activities: [ActivityItem] = []
    @Published private(set) var lastAction = "等待翻页笔输入"

    @Published private(set) var suppressOriginal: Bool
    @Published private(set) var exclusiveCapture: Bool
    @Published private(set) var compatibilityMode: Bool
    @Published private(set) var autoSelectNewDevices: Bool
    @Published private(set) var launchAtLogin = false

    private let defaults = UserDefaults.standard
    private let hidService = HIDClickerService()
    private let suppressionService = InputSuppressionService()
    private let wpsController = WPSController()
    private var selectedPersistentIDs: Set<String> = []
    private var statusTimer: Timer?
    private var screenObserver: NSObjectProtocol?

    private enum Keys {
        static let selectedDevices = "selectedDevices"
        static let suppressOriginal = "suppressOriginal"
        static let exclusiveCapture = "exclusiveCapture"
        static let compatibilityMode = "compatibilityMode"
        static let autoSelect = "autoSelectNewDevices"
    }

    var selectedDevices: [ClickerDevice] {
        devices.filter { selectedDeviceIDs.contains($0.id) }
    }

    var hasLikelyClicker: Bool {
        devices.contains { $0.isLikelyClicker }
    }

    var primaryStatusText: String {
        if isMonitoring {
            return selectedDeviceIDs.isEmpty ? "等待选择翻页笔" : "正在守护 WPS 演示"
        }
        return "守护已暂停"
    }

    var primaryStatusDetail: String {
        if !wpsRunning { return "打开 WPS 并开始放映后即可使用" }
        if selectedDeviceIDs.isEmpty { return "请在设备列表中选择你的翻页笔" }
        return "你可以继续在主屏使用其他软件"
    }

    private init() {
        suppressOriginal = defaults.object(forKey: Keys.suppressOriginal) as? Bool ?? true
        exclusiveCapture = defaults.object(forKey: Keys.exclusiveCapture) as? Bool ?? true
        compatibilityMode = defaults.bool(forKey: Keys.compatibilityMode)
        autoSelectNewDevices = defaults.object(forKey: Keys.autoSelect) as? Bool ?? true
        selectedPersistentIDs = Set(defaults.stringArray(forKey: Keys.selectedDevices) ?? [])
        launchAtLogin = SMAppService.mainApp.status == .enabled

        hidService.onDevicesChanged = { [weak self] devices in
            Task { @MainActor in self?.updateDevices(devices) }
        }
        hidService.onInput = { [weak self] event in
            Task { @MainActor in self?.handleInput(event) }
        }
        hidService.onDiagnostic = { [weak self] message in
            Task { @MainActor in self?.log(message, kind: .warning) }
        }
        suppressionService.onError = { [weak self] message in
            Task { @MainActor in self?.log(message, kind: .error) }
        }
        wpsController.onDiagnostic = { [weak self] message in
            Task { @MainActor in self?.log(message, kind: .warning) }
        }

        hidService.start()
        refreshStatus()
        startStatusTimer()
        observeScreens()
        log("翻页助手已启动，正在查找 USB 和蓝牙演示设备。", kind: .info)
    }

    deinit {
        statusTimer?.invalidate()
        if let screenObserver {
            NotificationCenter.default.removeObserver(screenObserver)
        }
    }

    func setMonitoring(_ enabled: Bool) {
        guard enabled != isMonitoring else { return }
        isMonitoring = enabled

        if enabled {
            refreshStatus()
            if !permissionStatus.inputMonitoring || !permissionStatus.accessibility {
                log("请允许“输入监听”和“辅助功能”权限，否则原按键拦截或 WPS 指令发送可能不可用。", kind: .warning)
            }
            if suppressOriginal {
                suppressionService.start()
            }
            hidService.updateExclusiveCapture(
                selectedIDs: selectedDeviceIDs,
                enabled: suppressOriginal && exclusiveCapture
            )
            log("演示守护已开启。普通鼠标和键盘操作不会被转发。", kind: .success)
        } else {
            suppressionService.stop()
            hidService.updateExclusiveCapture(selectedIDs: [], enabled: false)
            log("演示守护已暂停。", kind: .info)
        }
    }

    func toggleMonitoring() {
        setMonitoring(!isMonitoring)
    }

    func toggleDevice(_ device: ClickerDevice) {
        let selecting = !selectedPersistentIDs.contains(device.persistentID)
        if selecting {
            selectedPersistentIDs.insert(device.persistentID)
            for item in devices where item.persistentID == device.persistentID {
                selectedDeviceIDs.insert(item.id)
            }
        } else {
            selectedPersistentIDs.remove(device.persistentID)
            for item in devices where item.persistentID == device.persistentID {
                selectedDeviceIDs.remove(item.id)
            }
        }
        persistSelectedDevices()
        hidService.updateExclusiveCapture(
            selectedIDs: selectedDeviceIDs,
            enabled: isMonitoring && suppressOriginal && exclusiveCapture
        )
        lastAction = selecting ? "已选择 \(device.name)" : "已取消选择 \(device.name)"
    }

    func setSuppressOriginal(_ enabled: Bool) {
        suppressOriginal = enabled
        defaults.set(enabled, forKey: Keys.suppressOriginal)
        if isMonitoring {
            enabled ? suppressionService.start() : suppressionService.stop()
            hidService.updateExclusiveCapture(
                selectedIDs: selectedDeviceIDs,
                enabled: enabled && exclusiveCapture
            )
        }
    }

    func setExclusiveCapture(_ enabled: Bool) {
        exclusiveCapture = enabled
        defaults.set(enabled, forKey: Keys.exclusiveCapture)
        hidService.updateExclusiveCapture(
            selectedIDs: selectedDeviceIDs,
            enabled: isMonitoring && suppressOriginal && enabled
        )
    }

    func setCompatibilityMode(_ enabled: Bool) {
        compatibilityMode = enabled
        defaults.set(enabled, forKey: Keys.compatibilityMode)
        if enabled && !permissionStatus.accessibility {
            log("兼容模式需要“辅助功能”权限，用于短暂激活 WPS 后恢复当前软件。", kind: .warning)
        }
    }

    func setAutoSelectNewDevices(_ enabled: Bool) {
        autoSelectNewDevices = enabled
        defaults.set(enabled, forKey: Keys.autoSelect)
    }

    func setLaunchAtLogin(_ enabled: Bool) {
        do {
            if enabled {
                try SMAppService.mainApp.register()
            } else {
                try SMAppService.mainApp.unregister()
            }
            launchAtLogin = enabled
        } catch {
            launchAtLogin = SMAppService.mainApp.status == .enabled
            log("登录项设置失败：\(error.localizedDescription)", kind: .error)
        }
    }

    func refreshStatus() {
        permissionStatus = PermissionService.status()
        wpsRunning = wpsController.isRunning
        externalDisplayConnected = NSScreen.screens.count > 1
    }

    func requestInputMonitoring() {
        PermissionService.requestInputMonitoring()
    }

    func requestAccessibility() {
        PermissionService.requestAccessibility()
    }

    func openInputMonitoringSettings() {
        PermissionService.openInputMonitoringSettings()
    }

    func openAccessibilitySettings() {
        PermissionService.openAccessibilitySettings()
    }

    func openWPS() {
        for bundleID in ["com.kingsoft.wpsoffice.mac", "com.kingsoft.wpsoffice.mac.global"] {
            guard let url = NSWorkspace.shared.urlForApplication(withBundleIdentifier: bundleID) else {
                continue
            }
            let configuration = NSWorkspace.OpenConfiguration()
            NSWorkspace.shared.openApplication(at: url, configuration: configuration) { [weak self] _, error in
                Task { @MainActor in
                    if let error {
                        self?.log("无法打开 WPS：\(error.localizedDescription)", kind: .error)
                    }
                    self?.refreshStatus()
                }
            }
            return
        }
        log("未找到 WPS Office for Mac，请先安装并打开 WPS。", kind: .warning)
    }

    func clearLog() {
        activities.removeAll()
    }

    private func updateDevices(_ newDevices: [ClickerDevice]) {
        devices = newDevices
        selectedDeviceIDs = Set(newDevices.filter {
            selectedPersistentIDs.contains($0.persistentID)
        }.map(\.id))

        if autoSelectNewDevices {
            for device in newDevices where device.isLikelyClicker && !device.id.isEmpty {
                selectedPersistentIDs.insert(device.persistentID)
                selectedDeviceIDs.insert(device.id)
            }
        }
        persistSelectedDevices()

        if isMonitoring {
            hidService.updateExclusiveCapture(
                selectedIDs: selectedDeviceIDs,
                enabled: suppressOriginal && exclusiveCapture
            )
        }
    }

    private func handleInput(_ event: ClickerInputEvent) {
        guard selectedDeviceIDs.contains(event.deviceID) else { return }
        guard let action = event.action, let keyCode = event.keyCode else { return }

        if isMonitoring && suppressOriginal && !hidService.isExclusivelyCaptured(event.deviceID) {
            suppressionService.recordHIDEvent(keyCode: keyCode, isPressed: event.isPressed)
        }

        guard isMonitoring, event.isPressed else { return }
        lastAction = "\(action.rawValue) · \(deviceName(for: event.deviceID))"
        let sent = wpsController.send(
            action: action,
            originalKeyCode: keyCode,
            compatibilityMode: compatibilityMode
        )
        if sent {
            log("\(deviceName(for: event.deviceID)) → WPS：\(action.rawValue)", kind: .success)
        }
    }

    private func deviceName(for id: String) -> String {
        devices.first(where: { $0.id == id })?.name ?? "翻页笔"
    }

    private func persistSelectedDevices() {
        defaults.set(Array(selectedPersistentIDs), forKey: Keys.selectedDevices)
    }

    private func log(_ message: String, kind: ActivityItem.Kind) {
        activities.insert(ActivityItem(message: message, kind: kind), at: 0)
        if activities.count > 80 {
            activities.removeLast(activities.count - 80)
        }
    }

    private func startStatusTimer() {
        statusTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.refreshStatus() }
        }
    }

    private func observeScreens() {
        externalDisplayConnected = NSScreen.screens.count > 1
        screenObserver = NotificationCenter.default.addObserver(
            forName: NSApplication.didChangeScreenParametersNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                self?.externalDisplayConnected = NSScreen.screens.count > 1
            }
        }
    }
}
