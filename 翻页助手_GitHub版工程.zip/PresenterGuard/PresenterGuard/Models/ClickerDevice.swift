import Foundation
import CoreGraphics

enum DeviceTransport: String, Codable {
    case usb = "USB"
    case bluetooth = "蓝牙"
    case builtIn = "内置"
    case other = "其他"
}

struct ClickerDevice: Identifiable, Hashable, Codable {
    let id: String
    let persistentID: String
    let name: String
    let manufacturer: String
    let vendorID: Int
    let productID: Int
    let registryID: UInt64
    let transport: DeviceTransport
    let isLikelyClicker: Bool

    var subtitle: String {
        let maker = manufacturer.isEmpty ? "未知厂商" : manufacturer
        return "\(transport.rawValue) · \(maker) · \(String(format: "%04X:%04X", vendorID, productID))"
    }
}

enum PresentationAction: String, Codable {
    case next = "下一页"
    case previous = "上一页"
    case blackScreen = "黑屏"
    case whiteScreen = "白屏"
    case startPresentation = "开始播放"
    case endPresentation = "结束播放"
}

struct ClickerInputEvent {
    let deviceID: String
    let usagePage: Int
    let usage: Int
    let isPressed: Bool
    let keyCode: CGKeyCode?
    let action: PresentationAction?

    static func make(deviceID: String, usagePage: Int, usage: Int, value: Int) -> ClickerInputEvent {
        let mapped = KeyMap.map(usagePage: usagePage, usage: usage)
        return ClickerInputEvent(
            deviceID: deviceID,
            usagePage: usagePage,
            usage: usage,
            isPressed: value != 0,
            keyCode: mapped.keyCode,
            action: mapped.action
        )
    }
}

struct ActivityItem: Identifiable {
    let id = UUID()
    let date = Date()
    let message: String
    let kind: Kind

    enum Kind {
        case success, info, warning, error
    }
}

private enum KeyMap {
    static func map(usagePage: Int, usage: Int) -> (keyCode: CGKeyCode?, action: PresentationAction?) {
        if usagePage == 0x07 {
            switch usage {
            case 0x28: return (36, .next)              // Return
            case 0x2C: return (49, .next)              // Space
            case 0x4B: return (116, .previous)         // Page Up
            case 0x4E: return (121, .next)             // Page Down
            case 0x4F: return (124, .next)             // Right Arrow
            case 0x50: return (123, .previous)         // Left Arrow
            case 0x51: return (125, .next)             // Down Arrow
            case 0x52: return (126, .previous)         // Up Arrow
            case 0x05: return (11, .blackScreen)       // B
            case 0x1A: return (13, .whiteScreen)       // W
            case 0x29: return (53, .endPresentation)   // Escape
            case 0x3E: return (96, .startPresentation) // F5
            default: return (nil, nil)
            }
        }

        if usagePage == 0x0C {
            switch usage {
            case 0xB5: return (121, .next)             // Scan Next Track
            case 0xB6: return (116, .previous)         // Scan Previous Track
            case 0xCD: return (96, .startPresentation) // Play / Pause
            default: return (nil, nil)
            }
        }

        if usagePage == 0x09 {
            switch usage {
            case 1: return (121, .next)
            case 2: return (116, .previous)
            default: return (nil, nil)
            }
        }

        return (nil, nil)
    }

    static func fallbackKeyCode(for action: PresentationAction) -> CGKeyCode {
        switch action {
        case .next: return 121
        case .previous: return 116
        case .blackScreen: return 11
        case .whiteScreen: return 13
        case .startPresentation: return 96
        case .endPresentation: return 53
        }
    }
}
