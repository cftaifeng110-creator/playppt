import Foundation
import IOKit
import IOKit.hid

/// Discovers keyboard-like USB and Bluetooth devices and receives values directly
/// from the HID device, before they are mixed with the built-in keyboard stream.
final class HIDClickerService {
    var onDevicesChanged: (([ClickerDevice]) -> Void)?
    var onInput: ((ClickerInputEvent) -> Void)?
    var onDiagnostic: ((String) -> Void)?

    private var manager: IOHIDManager?
    private var rawDevices: [String: IOHIDDevice] = [:]
    private var descriptions: [String: ClickerDevice] = [:]
    private var exclusivelyOpened: Set<String> = []
    private var isStarted = false

    func start() {
        guard !isStarted else { return }
        isStarted = true

        let manager = IOHIDManagerCreate(kCFAllocatorDefault, IOOptionBits(kIOHIDOptionsTypeNone))
        self.manager = manager

        // Presentation remotes usually expose a keyboard, keypad, consumer-control,
        // or button interface. Matching all four also covers dual-mode remotes.
        let matches: [[String: Int]] = [
            [kIOHIDDeviceUsagePageKey: 0x01, kIOHIDDeviceUsageKey: 0x06],
            [kIOHIDDeviceUsagePageKey: 0x01, kIOHIDDeviceUsageKey: 0x07],
            [kIOHIDDeviceUsagePageKey: 0x0C, kIOHIDDeviceUsageKey: 0x01],
            [kIOHIDDeviceUsagePageKey: 0x09]
        ]
        IOHIDManagerSetDeviceMatchingMultiple(manager, matches as CFArray)

        let context = Unmanaged.passUnretained(self).toOpaque()
        IOHIDManagerRegisterDeviceMatchingCallback(manager, { context, _, _, device in
            guard let context else { return }
            let service = Unmanaged<HIDClickerService>.fromOpaque(context).takeUnretainedValue()
            service.deviceAdded(device)
        }, context)
        IOHIDManagerRegisterDeviceRemovalCallback(manager, { context, _, _, device in
            guard let context else { return }
            let service = Unmanaged<HIDClickerService>.fromOpaque(context).takeUnretainedValue()
            service.deviceRemoved(device)
        }, context)
        IOHIDManagerRegisterInputValueCallback(manager, { context, _, _, value in
            guard let context else { return }
            let service = Unmanaged<HIDClickerService>.fromOpaque(context).takeUnretainedValue()
            service.valueReceived(value)
        }, context)

        IOHIDManagerScheduleWithRunLoop(manager, CFRunLoopGetMain(), CFRunLoopMode.defaultMode.rawValue)
        let result = IOHIDManagerOpen(manager, IOOptionBits(kIOHIDOptionsTypeNone))
        if result != kIOReturnSuccess {
            onDiagnostic?("HID 管理器打开失败（\(String(format: "0x%08X", result))）。请检查“输入监听”权限。")
        }
    }

    func stop() {
        guard let manager else { return }
        for id in exclusivelyOpened {
            if let device = rawDevices[id] {
                IOHIDDeviceClose(device, IOOptionBits(kIOHIDOptionsTypeSeizeDevice))
            }
        }
        exclusivelyOpened.removeAll()
        IOHIDManagerUnscheduleFromRunLoop(manager, CFRunLoopGetMain(), CFRunLoopMode.defaultMode.rawValue)
        IOHIDManagerClose(manager, IOOptionBits(kIOHIDOptionsTypeNone))
        self.manager = nil
        rawDevices.removeAll()
        descriptions.removeAll()
        isStarted = false
    }

    func isExclusivelyCaptured(_ id: String) -> Bool {
        exclusivelyOpened.contains(id)
    }

    func updateExclusiveCapture(selectedIDs: Set<String>, enabled: Bool) {
        for id in exclusivelyOpened where !enabled || !selectedIDs.contains(id) {
            if let device = rawDevices[id] {
                IOHIDDeviceClose(device, IOOptionBits(kIOHIDOptionsTypeSeizeDevice))
            }
            exclusivelyOpened.remove(id)
        }

        guard enabled else { return }
        for id in selectedIDs where !exclusivelyOpened.contains(id) {
            guard let device = rawDevices[id] else { continue }
            let result = IOHIDDeviceOpen(device, IOOptionBits(kIOHIDOptionsTypeSeizeDevice))
            if result == kIOReturnSuccess {
                exclusivelyOpened.insert(id)
            } else {
                onDiagnostic?("“\(descriptions[id]?.name ?? id)”无法独占打开，将使用安全事件匹配模式。")
            }
        }
    }

    private func deviceAdded(_ device: IOHIDDevice) {
        let description = describe(device)
        rawDevices[description.id] = device
        descriptions[description.id] = description
        publishDevices()
    }

    private func deviceRemoved(_ device: IOHIDDevice) {
        let id = describe(device).id
        if exclusivelyOpened.contains(id) {
            IOHIDDeviceClose(device, IOOptionBits(kIOHIDOptionsTypeSeizeDevice))
            exclusivelyOpened.remove(id)
        }
        rawDevices.removeValue(forKey: id)
        descriptions.removeValue(forKey: id)
        publishDevices()
    }

    private func valueReceived(_ value: IOHIDValue) {
        let element = IOHIDValueGetElement(value)
        let device = IOHIDElementGetDevice(element)
        let id = describe(device).id
        let usagePage = Int(IOHIDElementGetUsagePage(element))
        let usage = Int(IOHIDElementGetUsage(element))
        let integerValue = IOHIDValueGetIntegerValue(value)

        let event = ClickerInputEvent.make(
            deviceID: id,
            usagePage: usagePage,
            usage: usage,
            value: integerValue
        )
        guard event.action != nil else { return }
        DispatchQueue.main.async { [weak self] in
            self?.onInput?(event)
        }
    }

    private func publishDevices() {
        let devices = descriptions.values.sorted {
            if $0.isLikelyClicker != $1.isLikelyClicker { return $0.isLikelyClicker }
            return $0.name.localizedCompare($1.name) == .orderedAscending
        }
        DispatchQueue.main.async { [weak self] in
            self?.onDevicesChanged?(devices)
        }
    }

    private func describe(_ device: IOHIDDevice) -> ClickerDevice {
        let name = stringProperty(device, kIOHIDProductKey) ?? "HID 演示设备"
        let manufacturer = stringProperty(device, kIOHIDManufacturerKey) ?? ""
        let vendorID = intProperty(device, kIOHIDVendorIDKey)
        let productID = intProperty(device, kIOHIDProductIDKey)
        let transportString = stringProperty(device, kIOHIDTransportKey)?.lowercased() ?? ""
        let serial = stringProperty(device, kIOHIDSerialNumberKey) ?? ""
        let locationID = intProperty(device, kIOHIDLocationIDKey)
        let builtIn = (IOHIDDeviceGetProperty(device, kIOHIDBuiltInKey as CFString) as? Bool) ?? false

        let service = IOHIDDeviceGetService(device)
        var registryID: UInt64 = 0
        if service != 0 {
            IORegistryEntryGetRegistryEntryID(service, &registryID)
        }

        let transport: DeviceTransport
        if builtIn {
            transport = .builtIn
        } else if transportString.contains("bluetooth") {
            transport = .bluetooth
        } else if transportString.contains("usb") {
            transport = .usb
        } else {
            transport = .other
        }

        // Registry ID distinguishes identical receivers. Serial/location provides
        // a deterministic fallback during device removal callbacks.
        let identity = registryID != 0
            ? "R\(registryID)"
            : "\(vendorID)-\(productID)-\(locationID)-\(serial)"
        // Unlike the session registry ID, this survives reconnects and also links
        // multiple HID interfaces exposed by the same physical presentation remote.
        let persistentToken = serial.isEmpty ? "\(name)-\(manufacturer)" : serial
        let persistentID = "\(vendorID)-\(productID)-\(persistentToken)"
        let lowerName = "\(name) \(manufacturer)".lowercased()
        let keywords = [
            "presenter", "presentation", "clicker", "remote", "laser pointer",
            "pointer presenter", "wireless presenter", "翻页", "演示器", "翻頁"
        ]
        let likely = !builtIn && keywords.contains(where: { lowerName.contains($0) })

        return ClickerDevice(
            id: identity,
            persistentID: persistentID,
            name: name,
            manufacturer: manufacturer,
            vendorID: vendorID,
            productID: productID,
            registryID: registryID,
            transport: transport,
            isLikelyClicker: likely
        )
    }

    private func stringProperty(_ device: IOHIDDevice, _ key: String) -> String? {
        IOHIDDeviceGetProperty(device, key as CFString) as? String
    }

    private func intProperty(_ device: IOHIDDevice, _ key: String) -> Int {
        if let number = IOHIDDeviceGetProperty(device, key as CFString) as? NSNumber {
            return number.intValue
        }
        return 0
    }
}
