import Foundation
import CoreGraphics
import QuartzCore

/// Filters only keyboard events that were just observed on a selected HID remote.
/// All unrelated keyboard and mouse events pass through untouched.
final class InputSuppressionService {
    var onError: ((String) -> Void)?

    private struct PendingEvent {
        let keyCode: CGKeyCode
        let isPressed: Bool
        let timestamp: CFTimeInterval
    }

    private var eventTap: CFMachPort?
    private var runLoopSource: CFRunLoopSource?
    private var pending: [PendingEvent] = []
    private let matchWindow: CFTimeInterval = 0.30

    var isRunning: Bool { eventTap != nil }

    func start() {
        guard eventTap == nil else { return }
        let mask = (CGEventMask(1) << CGEventType.keyDown.rawValue)
            | (CGEventMask(1) << CGEventType.keyUp.rawValue)
        let context = Unmanaged.passUnretained(self).toOpaque()

        guard let tap = CGEvent.tapCreate(
            tap: .cgSessionEventTap,
            place: .headInsertEventTap,
            options: .defaultTap,
            eventsOfInterest: mask,
            callback: { _, type, event, userInfo in
                guard let userInfo else { return Unmanaged.passUnretained(event) }
                let service = Unmanaged<InputSuppressionService>
                    .fromOpaque(userInfo)
                    .takeUnretainedValue()

                if type == .tapDisabledByTimeout || type == .tapDisabledByUserInput {
                    if let tap = service.eventTap {
                        CGEvent.tapEnable(tap: tap, enable: true)
                    }
                    return Unmanaged.passUnretained(event)
                }

                guard type == .keyDown || type == .keyUp else {
                    return Unmanaged.passUnretained(event)
                }
                let keyCode = CGKeyCode(event.getIntegerValueField(.keyboardEventKeycode))
                let shouldSuppress = service.consumeMatchingEvent(
                    keyCode: keyCode,
                    isPressed: type == .keyDown
                )
                return shouldSuppress ? nil : Unmanaged.passUnretained(event)
            },
            userInfo: context
        ) else {
            onError?("无法创建按键过滤器。请在“系统设置 → 隐私与安全性”中允许翻页助手使用“输入监听”和“辅助功能”。")
            return
        }

        eventTap = tap
        guard let source = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, tap, 0) else {
            eventTap = nil
            onError?("无法启动按键过滤器的运行循环。")
            return
        }
        runLoopSource = source
        CFRunLoopAddSource(CFRunLoopGetMain(), source, .commonModes)
        CGEvent.tapEnable(tap: tap, enable: true)
    }

    func stop() {
        if let tap = eventTap {
            CGEvent.tapEnable(tap: tap, enable: false)
            CFMachPortInvalidate(tap)
        }
        if let source = runLoopSource {
            CFRunLoopRemoveSource(CFRunLoopGetMain(), source, .commonModes)
        }
        eventTap = nil
        runLoopSource = nil
        pending.removeAll()
    }

    func recordHIDEvent(keyCode: CGKeyCode, isPressed: Bool) {
        let now = CACurrentMediaTime()
        pending.removeAll { now - $0.timestamp > matchWindow }
        pending.append(PendingEvent(keyCode: keyCode, isPressed: isPressed, timestamp: now))
    }

    private func consumeMatchingEvent(keyCode: CGKeyCode, isPressed: Bool) -> Bool {
        let now = CACurrentMediaTime()
        pending.removeAll { now - $0.timestamp > matchWindow }
        guard let index = pending.firstIndex(where: {
            $0.keyCode == keyCode && $0.isPressed == isPressed
        }) else {
            return false
        }
        pending.remove(at: index)
        return true
    }
}
