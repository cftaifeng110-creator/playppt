import Foundation
import ApplicationServices
import AppKit

struct PermissionStatus {
    let inputMonitoring: Bool
    let accessibility: Bool

    var readyForBasicUse: Bool { inputMonitoring && accessibility }
}

enum PermissionService {
    static func status() -> PermissionStatus {
        PermissionStatus(
            inputMonitoring: CGPreflightListenEventTapAccess(),
            accessibility: AXIsProcessTrusted()
        )
    }

    static func requestInputMonitoring() {
        _ = CGRequestListenEventTapAccess()
        openInputMonitoringSettings()
    }

    static func requestAccessibility() {
        let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue(): true] as CFDictionary
        _ = AXIsProcessTrustedWithOptions(options)
    }

    static func openInputMonitoringSettings() {
        openSettings("x-apple.systempreferences:com.apple.preference.security?Privacy_ListenEvent")
    }

    static func openAccessibilitySettings() {
        openSettings("x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility")
    }

    private static func openSettings(_ value: String) {
        guard let url = URL(string: value) else { return }
        NSWorkspace.shared.open(url)
    }
}
