import Foundation
import AppKit
import CoreGraphics

final class WPSController {
    var onDiagnostic: ((String) -> Void)?

    private let bundleIdentifiers: Set<String> = [
        "com.kingsoft.wpsoffice.mac",
        "com.kingsoft.wpsoffice.mac.global"
    ]

    var runningApplication: NSRunningApplication? {
        let apps = NSWorkspace.shared.runningApplications
        if let exact = apps.first(where: {
            guard let bundleID = $0.bundleIdentifier else { return false }
            return bundleIdentifiers.contains(bundleID)
        }) {
            return exact
        }
        return apps.first(where: {
            guard !$0.isTerminated else { return false }
            let name = $0.localizedName?.lowercased() ?? ""
            return name.contains("wps")
        })
    }

    var isRunning: Bool { runningApplication != nil }

    @discardableResult
    func send(
        action: PresentationAction,
        originalKeyCode: CGKeyCode?,
        compatibilityMode: Bool
    ) -> Bool {
        guard let target = runningApplication else {
            onDiagnostic?("未检测到正在运行的 WPS，请先打开演示文稿。")
            return false
        }

        let keyCode = originalKeyCode ?? fallbackKeyCode(for: action)
        if compatibilityMode {
            sendWithTemporaryActivation(keyCode: keyCode, target: target)
        } else {
            post(keyCode: keyCode, keyDown: true, to: target.processIdentifier)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.035) {
                self.post(keyCode: keyCode, keyDown: false, to: target.processIdentifier)
            }
        }
        return true
    }

    private func post(keyCode: CGKeyCode, keyDown: Bool, to pid: pid_t) {
        let source = CGEventSource(stateID: .hidSystemState)
        guard let event = CGEvent(keyboardEventSource: source, virtualKey: keyCode, keyDown: keyDown) else {
            return
        }
        event.flags = []
        event.postToPid(pid)
    }

    /// Some WPS builds ignore inactive-process events. This opt-in fallback briefly
    /// activates WPS, sends the key, then restores the user's previous application.
    private func sendWithTemporaryActivation(keyCode: CGKeyCode, target: NSRunningApplication) {
        let previous = NSWorkspace.shared.frontmostApplication
        target.activate(options: [.activateAllWindows])

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.14) {
            let source = CGEventSource(stateID: .hidSystemState)
            if let down = CGEvent(keyboardEventSource: source, virtualKey: keyCode, keyDown: true) {
                down.flags = []
                down.post(tap: .cgSessionEventTap)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.04) {
                if let up = CGEvent(keyboardEventSource: source, virtualKey: keyCode, keyDown: false) {
                    up.flags = []
                    up.post(tap: .cgSessionEventTap)
                }
                if let previous, previous.processIdentifier != target.processIdentifier {
                    previous.activate(options: [.activateAllWindows])
                }
            }
        }
    }

    private func fallbackKeyCode(for action: PresentationAction) -> CGKeyCode {
        switch action {
        case .next: return 121
        case .previous: return 116
        case .blackScreen: return 11
        case .whiteScreen: return 13
        case .startPresentation: return 96
        case .endPresentation: return 53
        }
    }
}
