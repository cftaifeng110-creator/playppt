import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var model: AppModel
    @State private var section: AppSection = .dashboard

    var body: some View {
        HStack(spacing: 0) {
            Sidebar(selection: $section)
                .frame(width: 196)
                .background(Color(nsColor: .controlBackgroundColor))

            Divider()

            VStack(spacing: 0) {
                HeaderView(section: section)
                Divider()
                ScrollView {
                    Group {
                        switch section {
                        case .dashboard: DashboardView()
                        case .devices: DevicesView()
                        case .activity: ActivityView()
                        case .settings: AppSettingsView()
                        }
                    }
                    .padding(24)
                    .frame(maxWidth: 980)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color(nsColor: .windowBackgroundColor))
            }
        }
        .frame(minWidth: 860, minHeight: 590)
        .onAppear { model.refreshStatus() }
    }
}

private enum AppSection: String, CaseIterable {
    case dashboard = "概览"
    case devices = "翻页笔"
    case activity = "事件记录"
    case settings = "设置"

    var icon: String {
        switch self {
        case .dashboard: return "rectangle.on.rectangle"
        case .devices: return "dot.radiowaves.left.and.right"
        case .activity: return "list.bullet.rectangle"
        case .settings: return "gearshape"
        }
    }
}

private struct Sidebar: View {
    @EnvironmentObject private var model: AppModel
    @Binding var selection: AppSection

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(spacing: 11) {
                Image(nsImage: NSApplication.shared.applicationIconImage)
                    .resizable()
                    .frame(width: 38, height: 38)
                VStack(alignment: .leading, spacing: 2) {
                    Text("翻页助手")
                        .font(.headline)
                    Text("PresenterGuard")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 22)

            VStack(spacing: 5) {
                ForEach(AppSection.allCases, id: \.self) { item in
                    Button {
                        selection = item
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: item.icon)
                                .frame(width: 18)
                            Text(item.rawValue)
                                .font(.system(size: 13, weight: .medium))
                            Spacer()
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 9)
                        .foregroundStyle(selection == item ? Color.accentColor : .primary)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(selection == item ? Color.accentColor.opacity(0.12) : .clear)
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 10)

            Spacer()

            VStack(alignment: .leading, spacing: 9) {
                HStack(spacing: 7) {
                    StatusDot(color: model.isMonitoring ? .green : .gray)
                    Text(model.isMonitoring ? "守护运行中" : "守护已暂停")
                        .font(.caption.weight(.medium))
                }
                Text(model.selectedDeviceIDs.isEmpty ? "尚未选择设备" : "已选 \(model.selectedDeviceIDs.count) 个设备")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            .padding(14)
            .background(Color(nsColor: .textBackgroundColor).opacity(0.65), in: RoundedRectangle(cornerRadius: 10))
            .padding(12)
        }
    }
}

private struct HeaderView: View {
    let section: AppSection

    var body: some View {
        HStack {
            Text(section.rawValue)
                .font(.title2.weight(.semibold))
            Spacer()
            if section == .dashboard {
                Text("输入仅在本机处理")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.horizontal, 24)
        .frame(height: 64)
        .background(Color(nsColor: .windowBackgroundColor))
    }
}

private struct DashboardView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            if !model.permissionStatus.readyForBasicUse {
                PermissionBanner()
            }

            Card {
                HStack(spacing: 18) {
                    ZStack {
                        Circle()
                            .fill(model.isMonitoring ? Color.green.opacity(0.12) : Color.secondary.opacity(0.10))
                        Image(systemName: model.isMonitoring ? "checkmark.circle.fill" : "pause.circle.fill")
                            .font(.system(size: 30))
                            .foregroundStyle(model.isMonitoring ? .green : .secondary)
                    }
                    .frame(width: 58, height: 58)

                    VStack(alignment: .leading, spacing: 6) {
                        Text(model.primaryStatusText)
                            .font(.title3.weight(.semibold))
                        Text(model.primaryStatusDetail)
                            .font(.callout)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button(model.isMonitoring ? "暂停守护" : "开启守护") {
                        model.toggleMonitoring()
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .tint(model.isMonitoring ? Color(nsColor: .systemGray) : .accentColor)
                }
            }

            HStack(spacing: 14) {
                StatusCard(
                    title: "扩展屏幕",
                    value: model.externalDisplayConnected ? "已连接" : "未连接",
                    detail: model.externalDisplayConnected ? "可将放映窗口放到扩展屏" : "请连接投影或扩展显示器",
                    icon: "display.2",
                    good: model.externalDisplayConnected
                )
                StatusCard(
                    title: "WPS 演示",
                    value: model.wpsRunning ? "已运行" : "未运行",
                    detail: model.wpsRunning ? "可接收定向翻页指令" : "请先打开演示文稿",
                    icon: "play.rectangle",
                    good: model.wpsRunning
                )
                StatusCard(
                    title: "翻页笔",
                    value: model.selectedDeviceIDs.isEmpty ? "未选择" : "已就绪",
                    detail: model.selectedDeviceIDs.isEmpty ? "在设备页选择 USB 或蓝牙设备" : "已选择 \(model.selectedDeviceIDs.count) 个输入设备",
                    icon: "dot.radiowaves.left.and.right",
                    good: !model.selectedDeviceIDs.isEmpty
                )
            }

            Card {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Label("最近输入", systemImage: "keyboard")
                            .font(.headline)
                        Spacer()
                        Text(model.lastAction)
                            .font(.callout)
                            .foregroundStyle(.secondary)
                    }
                    Divider()
                    HStack(spacing: 12) {
                        Image(systemName: "1.circle.fill").foregroundStyle(Color.accentColor)
                        Text("在 WPS 中开始放映，并将放映窗口置于扩展屏。")
                    }
                    HStack(spacing: 12) {
                        Image(systemName: "2.circle.fill").foregroundStyle(Color.accentColor)
                        Text("回到主屏打开其他软件，保持翻页助手在后台运行。")
                    }
                    HStack(spacing: 12) {
                        Image(systemName: "3.circle.fill").foregroundStyle(Color.accentColor)
                        Text("使用翻页笔；你的电脑键盘、鼠标仍归当前软件使用。")
                    }
                }
                .font(.callout)
            }

            if !model.wpsRunning {
                Button("打开 WPS Office") { model.openWPS() }
            }
        }
    }
}

private struct PermissionBanner: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.orange)
            VStack(alignment: .leading, spacing: 3) {
                Text("需要输入处理权限")
                    .font(.callout.weight(.semibold))
                Text("请允许“输入监听”和“辅助功能”，以识别、过滤并定向发送翻页指令。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if !model.permissionStatus.inputMonitoring {
                Button("允许输入监听") { model.requestInputMonitoring() }
            }
            if !model.permissionStatus.accessibility {
                Button("允许辅助功能") { model.requestAccessibility() }
            }
        }
        .padding(14)
        .background(Color.orange.opacity(0.09), in: RoundedRectangle(cornerRadius: 10))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.orange.opacity(0.18)))
    }
}

private struct DevicesView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Card {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("已发现的 HID 设备")
                                .font(.headline)
                            Text("支持 USB 接收器和蓝牙翻页笔。可手动选择名称未被自动识别的设备。")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text("\(model.devices.count) 个")
                            .font(.caption)
                            .padding(.horizontal, 9)
                            .padding(.vertical, 5)
                            .background(Color.secondary.opacity(0.10), in: Capsule())
                    }

                    if model.devices.isEmpty {
                        VStack(spacing: 12) {
                            Image(systemName: "dot.radiowaves.left.and.right")
                                .font(.system(size: 34))
                                .foregroundStyle(.secondary)
                            Text("正在等待翻页笔连接")
                                .font(.callout.weight(.medium))
                            Text("请插入 USB 接收器，或在 macOS 蓝牙设置中连接翻页笔。")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 38)
                    } else {
                        ForEach(model.devices) { device in
                            DeviceRow(device: device)
                            if device.id != model.devices.last?.id {
                                Divider()
                            }
                        }
                    }
                }
            }

            Card {
                Toggle(
                    "自动选择名称中包含 Presenter、Clicker、Remote 等特征的设备",
                    isOn: Binding(get: { model.autoSelectNewDevices }, set: model.setAutoSelectNewDevices)
                )
                Text("为避免干扰正常输入，应用不会自动选择 Mac 内置键盘或普通鼠标。若你的设备显示为通用键盘，请在上表手动选择一次。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(.top, 4)
            }
        }
    }
}

private struct DeviceRow: View {
    @EnvironmentObject private var model: AppModel
    let device: ClickerDevice

    private var selected: Bool { model.selectedDeviceIDs.contains(device.id) }

    var body: some View {
        Button { model.toggleDevice(device) } label: {
            HStack(spacing: 13) {
                Image(systemName: iconName)
                    .font(.title3)
                    .foregroundStyle(selected ? Color.accentColor : .secondary)
                    .frame(width: 28)
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 8) {
                        Text(device.name)
                            .font(.callout.weight(.medium))
                            .foregroundStyle(.primary)
                        if device.isLikelyClicker {
                            Text("疑似翻页笔")
                                .font(.caption2)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(Color.accentColor.opacity(0.10), in: Capsule())
                        }
                    }
                    Text(device.subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: selected ? "checkmark.circle.fill" : "circle")
                    .font(.title3)
                    .foregroundStyle(selected ? Color.accentColor : Color.secondary.opacity(0.55))
            }
            .contentShape(Rectangle())
            .padding(.vertical, 5)
        }
        .buttonStyle(.plain)
    }

    private var iconName: String {
        switch device.transport {
        case .bluetooth: return "antenna.radiowaves.left.and.right"
        case .usb: return "cable.connector"
        case .builtIn: return "keyboard"
        case .other: return "keyboard"
        }
    }
}

private struct ActivityView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("本地事件记录")
                            .font(.headline)
                        Text("只记录设备名称、按键动作和运行状态，不记录你正常输入的内容。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button("清空") { model.clearLog() }
                        .disabled(model.activities.isEmpty)
                }
                Divider()
                if model.activities.isEmpty {
                    Text("暂无事件")
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 60)
                } else {
                    ForEach(model.activities) { item in
                        HStack(alignment: .top, spacing: 10) {
                            StatusDot(color: color(for: item.kind))
                                .padding(.top, 5)
                            Text(item.date, format: .dateTime.hour().minute().second())
                                .font(.caption.monospacedDigit())
                                .foregroundStyle(.secondary)
                                .frame(width: 70, alignment: .leading)
                            Text(item.message)
                                .font(.callout)
                                .textSelection(.enabled)
                            Spacer()
                        }
                        .padding(.vertical, 3)
                    }
                }
            }
        }
    }

    private func color(for kind: ActivityItem.Kind) -> Color {
        switch kind {
        case .success: return .green
        case .info: return .accentColor
        case .warning: return .orange
        case .error: return .red
        }
    }
}

private struct AppSettingsView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Card {
                VStack(alignment: .leading, spacing: 16) {
                    Text("输入处理").font(.headline)
                    Toggle(
                        "拦截已选翻页笔产生的原始按键",
                        isOn: Binding(get: { model.suppressOriginal }, set: model.setSuppressOriginal)
                    )
                    Text("防止翻页笔的方向键、空格等同时作用于你正在使用的软件。")
                        .settingDescription

                    Divider()
                    Toggle(
                        "优先尝试独占已选翻页笔",
                        isOn: Binding(get: { model.exclusiveCapture }, set: model.setExclusiveCapture)
                    )
                    .disabled(!model.suppressOriginal)
                    Text("独占失败时自动回退到 HID 与系统按键的安全匹配，不影响其他输入设备。")
                        .settingDescription

                    Divider()
                    Toggle(
                        "WPS 兼容模式（仅在直接转发无效时开启）",
                        isOn: Binding(get: { model.compatibilityMode }, set: model.setCompatibilityMode)
                    )
                    Text("开启后会短暂激活 WPS，再恢复之前使用的软件；可能出现焦点闪烁。")
                        .settingDescription
                }
            }

            Card {
                VStack(alignment: .leading, spacing: 16) {
                    Text("权限").font(.headline)
                    PermissionRow(
                        title: "输入监听",
                        detail: "识别翻页笔并过滤它模拟的键盘事件",
                        granted: model.permissionStatus.inputMonitoring,
                        action: model.openInputMonitoringSettings
                    )
                    Divider()
                    PermissionRow(
                        title: "辅助功能",
                        detail: "过滤原始按键、发送演示指令及 WPS 兼容模式",
                        granted: model.permissionStatus.accessibility,
                        action: model.requestAccessibility
                    )
                }
            }

            Card {
                Toggle(
                    "登录 Mac 后自动启动",
                    isOn: Binding(get: { model.launchAtLogin }, set: model.setLaunchAtLogin)
                )
                Text("建议在“系统设置 → 隐私与安全性”中同时允许翻页助手后台运行。")
                    .settingDescription
            }
        }
    }
}

private struct PermissionRow: View {
    let title: String
    let detail: String
    let granted: Bool
    let action: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: granted ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                .foregroundStyle(granted ? .green : .orange)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.callout.weight(.medium))
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Text(granted ? "已允许" : "未允许")
                .font(.caption)
                .foregroundStyle(.secondary)
            Button("打开设置", action: action)
        }
    }
}

private struct StatusCard: View {
    let title: String
    let value: String
    let detail: String
    let icon: String
    let good: Bool

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Image(systemName: icon).foregroundStyle(good ? Color.accentColor : .secondary)
                    Spacer()
                    StatusDot(color: good ? .green : .gray)
                }
                Text(title).font(.caption).foregroundStyle(.secondary)
                Text(value).font(.headline)
                Text(detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(maxWidth: .infinity)
    }
}

private struct Card<Content: View>: View {
    @ViewBuilder let content: Content

    var body: some View {
        content
            .padding(18)
            .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 12))
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.primary.opacity(0.055), lineWidth: 1)
            )
    }
}

private struct StatusDot: View {
    let color: Color

    var body: some View {
        Circle()
            .fill(color)
            .frame(width: 7, height: 7)
    }
}

private extension View {
    var settingDescription: some View {
        self
            .font(.caption)
            .foregroundStyle(.secondary)
    }
}
