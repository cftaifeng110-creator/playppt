#!/bin/zsh
set -euo pipefail

# Run on macOS with Xcode 15 or newer installed:
#   zsh Scripts/build_dmg.sh
# Optional: SIGN_IDENTITY="Developer ID Application: Your Name (TEAMID)" zsh Scripts/build_dmg.sh

ROOT="${0:A:h:h}"
PROJECT="$ROOT/PresenterGuard.xcodeproj"
DERIVED="$ROOT/build/DerivedData"
DIST="$ROOT/dist"
VERSION="1.0.0"
APP_NAME="PresenterGuard"
DISPLAY_NAME="翻页助手"
IDENTITY="${SIGN_IDENTITY:--}"

if [[ "$(uname)" != "Darwin" ]]; then
  echo "错误：此脚本必须在 macOS 上运行。"
  exit 1
fi
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "错误：未找到 Xcode。请先从 Mac App Store 安装 Xcode。"
  exit 1
fi

rm -rf "$DERIVED" "$DIST"
mkdir -p "$DERIVED" "$DIST"

xcodebuild \
  -project "$PROJECT" \
  -scheme "$APP_NAME" \
  -configuration Release \
  -derivedDataPath "$DERIVED" \
  CODE_SIGN_STYLE=Manual \
  CODE_SIGN_IDENTITY="$IDENTITY" \
  DEVELOPMENT_TEAM="" \
  ONLY_ACTIVE_ARCH=NO \
  build

APP="$DERIVED/Build/Products/Release/$APP_NAME.app"
if [[ ! -d "$APP" ]]; then
  echo "错误：构建完成但未找到 $APP"
  exit 1
fi

# Ad-hoc signing is sufficient for a locally built personal copy.
# For public distribution, use a Developer ID identity and notarize the DMG.
codesign --force --deep --sign "$IDENTITY" "$APP"
codesign --verify --deep --strict "$APP"

STAGING="$DIST/dmg-root"
mkdir -p "$STAGING"
ditto "$APP" "$STAGING/$DISPLAY_NAME.app"
ln -s /Applications "$STAGING/Applications"

hdiutil create \
  -volname "$DISPLAY_NAME" \
  -srcfolder "$STAGING" \
  -ov \
  -format UDZO \
  "$DIST/$DISPLAY_NAME-$VERSION.dmg"

echo ""
echo "完成：$DIST/$DISPLAY_NAME-$VERSION.dmg"
echo "打开 DMG，将“翻页助手”拖入 Applications 即可安装。"
